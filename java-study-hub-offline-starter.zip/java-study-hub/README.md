# Java Study Hub — offline-first Android starter

**Starter stage:** the study app UI and core study flows exist in `www/index.html`. This is not yet a signed APK/AAB or a published Play Store app.

## Included in this starter
- Java notes: Introduction, JDK/JRE/JVM, variables and data types, conditions/loops, methods, arrays, OOP, recursion, greedy algorithms.
- Code library with example code, sample output and explanations.
- DSA problem list with local statuses.
- Java MCQ quiz with instant explanations.
- Daily checklist, learned topics, bookmarks and progress summary.
- JSON export/import of progress.
- Responsive phone layout with no remote fonts, images, CDN libraries, API calls, analytics, login or network dependency in the study UI.

## Offline model
The HTML, CSS, JavaScript and initial study content are bundled into the app's `www` folder. Once packaged inside the Android application, the learning interface does not need internet access to open or use this bundled content. Progress uses device-local browser storage within the app. Uninstalling the app or clearing its storage can remove that progress; exporting a backup is provided.

The browser-only preview can be opened using `www/index.html`. Browser storage for local files varies, so that preview is not the final way to verify persistent offline behaviour. Test the packaged Android build in airplane mode, including after a force-close and cold start.

## Android build requirements
Capacitor's current setup guide requires Node.js 22+ and Android Studio with an Android SDK. See the official setup guide: https://capacitorjs.com/docs/getting-started/environment-setup

On a development computer:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Then use Android Studio to run the app on a device/emulator. For Play Store release, configure app icons and versioning, test thoroughly, create a signed Android App Bundle (`.aab`), complete the relevant Play Console forms, and submit for review. This starter does not include the generated Android project, release signing key, or AAB.

## Apper.io note
Apper.io's documented publishing flow is web publication. Native APK/AAB export for that product was not verified. Appery.io is a different platform. For the strict offline + Play Store requirement, use this bundled app with a native wrapper/build process rather than relying on a published website alone.
